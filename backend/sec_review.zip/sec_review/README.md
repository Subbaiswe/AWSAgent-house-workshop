# Security Review

## Tool Choice

We use **checkov** instead of cfn-nag because cfn-nag has a compatibility issue with Ruby 4.0. Its `kwalify` dependency uses the deprecated `StringScanner#peep` method (renamed to `peek` in Ruby 4.0), causing runtime errors.

## Scan Results

![Checkov scan results](checkov.png)

**Passed:** 5 | **Failed:** 4

### Failed Checks

All failures relate to the `RuntimeExecutionRole` using wildcard permissions (`*`) for Athena, Glue, S3, and Kinesis Video.

| Check | Issue |
|-------|-------|
| CKV_AWS_108 | Data exfiltration risk (s3:*) |
| CKV_AWS_111 | Write access without constraints |
| CKV_AWS_109 | Permissions management without constraints |
| CKV_AWS_110 | Privilege escalation risk |

### Acceptable for Workshop

These findings are acknowledged but acceptable here because:

- This is an **isolated workshop account** for illustrative purposes only
- No production data or cross-account access exists
- The broad permissions simplify the learning experience
- Resources are ephemeral and deleted after the workshop
